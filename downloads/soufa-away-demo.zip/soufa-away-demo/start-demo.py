#!/usr/bin/env python3
"""Serve the bundled demo locally; no npm install or backend required."""
import argparse
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import threading
import webbrowser

parser = argparse.ArgumentParser()
parser.add_argument("--port", type=int)
parser.add_argument("--no-browser", action="store_true")
args = parser.parse_args()
site = Path(__file__).resolve().parent / "site"
handler = partial(SimpleHTTPRequestHandler, directory=str(site))
server = None
for candidate in ([args.port] if args.port is not None else range(5197, 5217)):
    try:
        server = ThreadingHTTPServer(("127.0.0.1", candidate), handler)
        break
    except OSError:
        continue
if server is None:
    raise SystemExit("No local port is available. Try --port 5217.")
url = f"http://127.0.0.1:{server.server_port}/"
print(f"Demo ready: {url}\n2D investigation demo. Keep this window open. Ctrl+C to stop.", flush=True)
if not args.no_browser:
    threading.Timer(0.5, lambda: webbrowser.open(url)).start()
try:
    server.serve_forever()
except KeyboardInterrupt:
    pass
finally:
    server.server_close()
