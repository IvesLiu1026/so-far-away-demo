# So Far Away 展示發布

固定試玩網址：[GitHub Pages](https://ivesliu1026.github.io/so-far-away-demo/)。不依賴本機開機或臨時通道，未設定到期日；保留此倉庫與 Pages 設定即可持續使用同一網址。

發布倉庫為 `IvesLiu1026/so-far-away-demo`，公開內容只有編譯後遊戲、下載包及回報截圖。原始碼仍在私有的 `IvesLiu1026/judge-so-far-away`；沒有公開環境檔、後端或來源碼目錄。Pages 使用 `main` 根目錄，`.nojekyll` 保留靜態檔案。

- [離線下載包](https://ivesliu1026.github.io/so-far-away-demo/downloads/soufa-away-demo.zip)
- [本輪截圖（11/6）](https://ivesliu1026.github.io/so-far-away-demo/review/261106/)
- [截圖與圖說 ZIP](https://ivesliu1026.github.io/so-far-away-demo/downloads/soufa-review-20261106.zip)

本輪 11/6 靜音 DV 版已取得公開發布授權，使用上面的固定入口。舊 Cloudflare 臨時網址不作為本輪交付入口。瀏覽器進度依來源分開，舊網址的保存不會自動搬到新網址。

## 重建與更新

11/6 的靜音 DV 版本可分開建立根路徑與 Pages 產物，避免覆蓋正在驗收的根路徑版本：

```sh
npm run build
PUBLIC_BASE_PATH=/so-far-away-demo/ npm run build -- --outDir dist/pages-build-261106
PUBLIC_BASE_PATH=/so-far-away-demo/ PAGES_BUILD_DIR=dist/pages-build-261106/client PAGES_OUTPUT_DIR=dist/pages/261106/so-far-away-demo node scripts/package-pages.mjs
```

本輪新增 `media/` 影片與海報；發布時要連同該目錄複製。來源與驗收見 [11/6 迭代](demo-iteration-2026-11-06.md)。

先完成根路徑建置、離線包與 QA，再另建 Pages 子路徑版，避免把子路徑版誤裝入離線包：

```sh
npm run build
node scripts/package-demo.mjs
PUBLIC_BASE_PATH=/so-far-away-demo/ npm run build
PUBLIC_BASE_PATH=/so-far-away-demo/ PAGES_OUTPUT_DIR=dist/pages/next-release node scripts/package-pages.mjs
```

`package-pages.mjs` 保留 Vite 產生的模組路徑，並調整 Phaser 等執行期的素材字串。輸出應使用全新目錄，避免混入過期檔案。離線包可用 `DEMO_BUILD_DIR` 指向事先保存的根路徑建置。

取得公開發布授權後，將已驗證的輸出同步到發布倉庫，再加入 `downloads/` 與 `review/261106/`，提交推送 `main`。保留歷史截圖目錄。不得把專案根目錄直接複製到公開倉庫。來源倉庫另外提交及推送程式碼。

發布後確認 Pages 建置成功，公開首頁為 200、素材與字型無缺檔，再以公開網址跑 `smoke:test` 與回饋檢查。下載包與截圖 ZIP 應確認遠端雜湊符合本機且 ZIP 完整。驗收範圍見 [紀錄](demo-verification.md)。
