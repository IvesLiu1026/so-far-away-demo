So Far Away｜261106 靜音 DV 版 Demo

先完整解壓縮，保留 site 資料夾。

需要 Python 3 與新版 Chrome / Edge / Firefox。
正式展示採用 2D。
不需要安裝 Node.js、npm 套件或 Rust 後端。
繁中字體已包含於 site/fonts，授權見 site/fonts/OFL.txt，不需要外部字型服務。

Windows：執行 START-DEMO.bat。
macOS / Linux：在解壓縮資料夾執行 python3 start-demo.py。
macOS 也可執行 START-DEMO.command；若系統要求，可改用上述終端機指令。

啟動後瀏覽器會自動打開本機網址。預設使用 5197；被占用時會選下一個可用埠，以啟動視窗顯示為準。
展示期間保持命令列視窗開啟。也可自行指定：python3 start-demo.py --port 5198。
不要直接雙擊 site/index.html；遊戲模組需要透過本機 HTTP 伺服器載入。

操作稿與三案路線見 DEMO-GUIDE.md。
若附有 report-images 資料夾，可將其中的三案畫面與場景總覽用於報告。
預設重新整理可續玩，關閉分頁後重開會重設；要保留請在首頁勾選「關閉網頁後保留進度」。
保存限同一瀏覽器、同一網址。第一次展示建議選 KTV 案，再介紹 DNA 與少年案。
少年案 DV 是遊戲重建示意，並非真實案件影像。
