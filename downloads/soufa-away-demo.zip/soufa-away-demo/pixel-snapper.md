# Pixel Snapper 素材試作

來源：[Sprite Fusion Pixel Snapper](https://github.com/Hugo-Dz/spritefusion-pixel-snapper)，MIT 授權，作者 Hugo Duprez。固定來源提交為 `02f9315d73d3219274d17767b36d9a231a6b1f4b`。

這是離線素材工具。安裝及處理都在本機執行，不呼叫生成模型，不上傳素材，也不增加遊戲的瀏覽器依賴。安裝需要 Rust；預覽使用專案既有的 sharp。

```sh
npm run assets:pixel:install
npm run assets:pixel:preview -- public/assets/game/layers/sprite-detective-walk-v2.png
npm run assets:pixel:preview -- public/assets/game/layers/sprite-detective-inspect-v2.png
```

安裝於使用者快取目錄的 `so-far-away/pixel-snapper-<revision>/bin`。可用 `PIXEL_SNAPPER_BIN` 指定已安裝的 CLI。預覽寫入 `output/pixel-snapper/<素材名稱>/`，含原圖／自動網格／1px 網格的比較圖與尺寸報告，保留原始素材。

## 11/6 試作結果

使用 48 色，實際結果如下：

| 圖集 | 原圖 | 自動網格 | 指定 1px 網格 |
| --- | --- | --- | --- |
| 偵探走路 | 288×512 | 51×92 | 241×357 |
| 偵探調查 | 384×128 | 86×25 | 275×83 |

目前 Phaser 每格固定為 96×128。Pixel Snapper 在指定 1px 時仍會重新分配網格，整張圖集處理後會改變切格位置及角色比例，不能直接替換。這輪 demo 保留現有圖集。

後續新增像素素材時，可先處理單格，使用共用色盤，再重新排成固定尺寸圖集；驗收需檢查腳底基準、方向、透明邊緣與動畫閃色。工具適合整理像素網格，文件證物、人物照片和指定原圖應依各自來源流程處理。
